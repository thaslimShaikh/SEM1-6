class FirstOrderLogic:
    def __init__(self):
        self.domain = set()  
        self.predicates = {}  

    def add_to_domain(self, *objects):
        self.domain.update(objects)

    def add_predicate(self, predicate_name, predicate_function):
        self.predicates[predicate_name] = predicate_function

    def forall(self, predicate_name, *args):
        if predicate_name not in self.predicates:
            raise ValueError(f"Predicate {predicate_name} not defined.")

        predicate_function = self.predicates[predicate_name]
        for obj in self.domain:
            if not predicate_function(obj, *args):  
                return False  
        return True

    def exists(self, predicate_name, *args):
        if predicate_name not in self.predicates:
            raise ValueError(f"Predicate {predicate_name} not defined.")

        predicate_function = self.predicates[predicate_name]
        for obj in self.domain:
            if predicate_function(obj, *args):
                return True  
        return False

# Example usage
if __name__ == "__main__":
    fol = FirstOrderLogic()
    fol.add_to_domain("Alice", "Bob", "Charlie")
    
    def likes(x, y):
        """Predicate: Likes(x, y)"""
        # Simple predicate logic: Alice likes Bob, and Bob likes Charlie
        if x == "Alice" and y == "Bob":
            return True
        elif x == "Bob" and y == "Charlie":
            return True
        return False
    
    fol.add_predicate("Likes", likes)
    
    print(f"forall x Likes(x, Bob): {fol.forall('Likes', 'Bob')}")  # Should return False (Charlie doesn't like Bob)
    
    print(f"exists x Likes(x, Charlie): {fol.exists('Likes', 'Charlie')}")  # Should return True (Bob likes Charlie)
    
    print(f"exists x Likes(x, Alice): {fol.exists('Likes', 'Alice')}")  # Should return False (No one likes Alice)
