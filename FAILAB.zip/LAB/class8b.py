class Node:
    def __init__(self, utility=None, children=None):
        self.utility = utility  # Utility value (for terminal nodes)
        self.children = children if children is not None else []  # Child nodes

def alpha_beta(node, depth, alpha, beta, is_maximizing):
    # Base case: return the utility value for terminal nodes
    if node.utility is not None:
        return node.utility
    if is_maximizing:
        best_value = -float('inf')
        for child in node.children:
            value = alpha_beta(child, depth + 1, alpha, beta, False)
            best_value = max(best_value, value)
            alpha = max(alpha, best_value)
            if beta <= alpha:
                break  # Beta cut-off
        return best_value
    else:
        best_value = float('inf')
        for child in node.children:
            value = alpha_beta(child, depth + 1, alpha, beta, True)
            best_value = min(best_value, value)
            beta = min(beta, best_value)
            if beta <= alpha:
                break  # Alpha cut-off
        return best_value

# Create terminal nodes (Depth 2)
leaf1 = Node(3)
leaf2 = Node(5)
leaf3 = Node(2)
leaf4 = Node(8)

# Create Level 2 nodes (Maximizing nodes)
nodeA = Node(children=[leaf1, leaf2])  # Node A
nodeB = Node(children=[leaf3, leaf4])  # Node B

# Create the root node (Minimizing)
root = Node(children=[nodeA, nodeB])

# Compute the best value for the minimizing player with Alpha-Beta pruning
best_value = alpha_beta(root, 0, -float('inf'), float('inf'), False)
print("Best achievable score for the minimizing player with Alpha-Beta pruning:", best_value)
