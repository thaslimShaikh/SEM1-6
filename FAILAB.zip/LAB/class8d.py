def is_safe(board, row, col):
    # Check this column on upper side
    for i in range(row):
        if board[i][col] == 1:
            return False
    # Check upper diagonal on left side
    for i, j in zip(range(row, -1, -1), range(col, -1, -1)):
        if board[i][j] == 1:
            return False
    # Check upper diagonal on right side
    for i, j in zip(range(row, -1, -1), range(col, len(board))):
        if board[i][j] == 1:
            return False
    return True

def solve_n_queens_util(board, row):
    if row >= len(board):
        return True  # All queens are placed successfully
    for col in range(len(board)):
        if is_safe(board, row, col):
            board[row][col] = 1  # Place queen
            if solve_n_queens_util(board, row + 1):
                return True  # Recur to place rest of the queens
            board[row][col] = 0  # Backtrack
    return False  # Trigger backtracking

def solve_n_queens(n):
    board = [[0 for _ in range(n)] for _ in range(n)]
    if not solve_n_queens_util(board, 0):
        print("Solution does not exist")
        return
    # Print the solution
    for row in board:
        print(' '.join(['Q' if cell == 1 else '.' for cell in row]))

# Example usage:
n = 4  # Change this value for different sizes
solve_n_queens(n)
