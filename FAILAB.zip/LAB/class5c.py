import heapq

def greedy_best_first_search(graph, start, goal, heuristic):
    
    open_list = []
    heapq.heappush(open_list, (heuristic[start], start))

    visited = set()
    came_from = {}

    while open_list:
       
        _, current = heapq.heappop(open_list)
        if current == goal:
            path = []
            while current:
                path.append(current)
                current = came_from.get(current)
            path.reverse()
            return path
        visited.add(current)

        for neighbor in graph[current]:
            if neighbor not in visited:
                visited.add(neighbor)
                came_from[neighbor] = current
                heapq.heappush(open_list, (heuristic[neighbor], neighbor))

    return None

# Example usage
if __name__ == "__main__":
    # Define the graph as an adjacency list
    graph = {
        'A': ['B', 'C'],
        'B': ['A', 'D', 'E'],
        'C': ['A', 'F'],
        'D': ['B'],
        'E': ['B', 'G'],
        'F': ['C'],
        'G': ['E'],
    }

    # Define the heuristic function (estimated cost to goal)
    heuristic = {
        'A': 7,
        'B': 6,
        'C': 2,
        'D': 1,
        'E': 4,
        'F': 0,
        'G': 3,
    }
    start = 'A'
    goal = 'F'

    path = greedy_best_first_search(graph, start, goal, heuristic)
    if path:
        print("Path found:", path)
    else:
        print("No path found.")
