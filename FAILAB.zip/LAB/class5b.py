
def dfs(graph, start, goal, depth):
    if depth == 0:
        return start == goal
    elif depth > 0:
        for neighbor in graph.get(start, []):
            if dfs(graph, neighbor, goal, depth - 1):
                return True
    return False

#iterative deepening dfs!
def iddfs(graph, start, goal, max_depth):
    for depth in range(max_depth + 1):
        if dfs(graph, start, goal, depth):
            return True
    return False

#Example usage
if __name__ == "__main__":
    #Example graph represented as an adjacency list
    graph = {
        'A': ['B', 'C'],
        'B': ['D', 'E'],
        'C': ['F'],
        'D': [],
        'E': ['F'],
        'F': []
    }
    start_node = 'A'
    goal_node = 'F'
    max_search_depth = 3
    found = iddfs(graph, start_node, goal_node, max_search_depth)
    print(f"Goal {goal_node} found: {found}")

#depth-limited depth first search
#[] - adjacency list
