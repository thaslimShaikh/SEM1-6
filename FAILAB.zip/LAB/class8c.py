class Task:
    def __init__(self, name, subtasks=None):
        self.name = name
        self.subtasks = subtasks if subtasks else []

    def add_subtask(self, task):
        self.subtasks.append(task)

    def plan(self):
        print(f"Planning task: {self.name}")
        if self.subtasks:
            for subtask in self.subtasks:
                subtask.plan()
        else:
            print(f"Executing task: {self.name}")

# Example of hierarchical planning for autonomous driving
if __name__ == "__main__":
    main_task = Task("Navigate to destination")

    task1 = Task("Plan route")
    task1.add_subtask(Task("Obtain map data"))
    task1.add_subtask(Task("Choose best route"))

    task2 = Task("Drive to destination")
    task2.add_subtask(Task("Start engine"))
    task2.add_subtask(Task("Follow route"))

    follow_route = Task("Follow route")
    follow_route.add_subtask(Task("Handle traffic lights"))
    follow_route.add_subtask(Task("Avoid obstacles"))
    follow_route.add_subtask(Task("Maintain speed"))

    task2.add_subtask(follow_route)

    task3 = Task("Reach destination")
    task3.add_subtask(Task("Stop vehicle"))

    main_task.add_subtask(task1)
    main_task.add_subtask(task2)
    main_task.add_subtask(task3)

    main_task.plan()
