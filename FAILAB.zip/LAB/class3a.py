##you have to choose an action with maximum utility value??

class UtilityBasedReflexAgent:

    def __init__(self):
        # Define the utility function for different states
        self.utility = {
            'state1': 1,
            'state2': 0.5,
            'state3': 0,
            'state4': 0.2
        }

    def get_best_action(self, state):
        # Check if the current state has the defined utility
        if state not in self.utility:
            return 'Unknown State'
        # Get the action for the current state
        actions = {
            'state1': 'Action1',
            'state2': 'Action2',
            'state3': 'Action3',
            'state4': 'Action4'
        }
        return actions.get(state, 'Unknown Action')

    def decide_action(self, state):
        best_action = self.get_best_action(state)
        return best_action

# Example usage
if __name__ == "__main__":
    agent = UtilityBasedReflexAgent()
    # Test with different states
    states = ['state1', 'state2', 'state3', 'state4', 'unknown_state']
    for state in states:
        action = agent.decide_action(state)
        print(f"For state '{state}', the agent chooses '{action}'.")
