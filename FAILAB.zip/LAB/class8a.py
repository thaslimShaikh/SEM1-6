class Node:
    def __init__(self, utility=None, children=None):
        self.utility = utility  
        self.children = children if children is not None else []  

def minimax(node, depth, is_maximizing):
    if node.utility is not None:
        return node.utility
    if is_maximizing:
        best_value = -float('inf')
        for child in node.children:
            value = minimax(child, depth + 1, False)
            best_value = max(best_value, value)
        return best_value
    else:
        best_value = float('inf')
        for child in node.children:
            value = minimax(child, depth + 1, True)
            best_value = min(best_value, value)
        return best_value

# Create terminal nodes (Depth 2)
leaf1 = Node(7)  # Terminal Node 1
leaf2 = Node(5)  # Terminal Node 2
leaf3 = Node(6)  # Terminal Node 3
leaf4 = Node(8)  # Terminal Node 4

# Create Level 1 nodes (Maximizing nodes)
nodeA = Node(children=[leaf1, leaf2])  # Maximizing Node A
nodeB = Node(children=[leaf3, leaf4])  # Maximizing Node B

# Create the root node (Minimizing node)
root = Node(children=[nodeA, nodeB])  # Minimizing Root Node

# Compute the best value for the minimizing player
best_value = minimax(root, 0, False)
print("Best achievable score for the minimizing player:", best_value)
