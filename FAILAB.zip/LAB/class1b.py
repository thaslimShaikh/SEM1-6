class calculator:
    def __init__(self, a, b):
      self.num1 = a
      self.num2 = b
    def add(self):
      print("Addition: ", self.num1 + self.num2)
    def sub(self):
      print("Subtraction: ", self.num1 - self.num2)
a1 = calculator(2, 4)
a1.add()
a1.sub()
    