class ModelBasedReflexAgent:
    def __init__(self):
        self.internal_state = 'clean'

    def update_state(self, percept):
        if percept == 'dirt':
            self.internal_state = 'dirty'
        else:
            self.internal_state = 'clean'
          
    def choose_action(self):
        if self.internal_state == 'dirty':
            return 'clean'
        else:
            return 'move'

if __name__ == "__main__":
    agent = ModelBasedReflexAgent()
    
    percept = 'dirt'
    agent.update_state(percept)
    action = agent.choose_action()
    print(f"Percept: {percept}, Action: {action}")

    percept = 'clean'
    agent.update_state(percept)
    action = agent.choose_action()
    print(f"Percept: {percept}, Action: {action}")
