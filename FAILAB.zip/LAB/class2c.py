class GoalBasedAgent:
    def __init__(self, start_pos, goal_pos):
        self.position = start_pos
        self.goal_pos = goal_pos

    def move(self, action):
        if action == 'UP':
            self.position = (self.position[0], self.position[1] + 1)
        elif action == 'DOWN':
            self.position = (self.position[0], self.position[1] - 1)
        elif action == 'LEFT':
            self.position = (self.position[0] - 1, self.position[1])
        elif action == 'RIGHT':
            self.position = (self.position[0] + 1, self.position[1])

    def get_possible_actions(self):
        actions = []
        if self.position[1] < self.goal_pos[1]:
            actions.append('UP')
        if self.position[1] > self.goal_pos[1]:
            actions.append('DOWN')
        if self.position[0] < self.goal_pos[0]:
            actions.append('RIGHT')
        if self.position[0] > self.goal_pos[0]:
            actions.append('LEFT')
        return actions

    def plan_action(self):
        actions = self.get_possible_actions()
        return actions[0] if actions else None

    def update_position(self):
        action = self.plan_action()
        if action:
            print(f"Action: {action}")  # Debug print
            self.move(action)
        print(f"Updated Position: {self.position}")  # Debug print
        return self.position

# Main logic
start_position = (0, 0)
goal_position = (2, 3)
agent = GoalBasedAgent(start_position, goal_position)

while agent.position != goal_position:
    print(f"Current Position: {agent.position}")
    agent.update_position()
print(f"Goal Reached: {agent.position}")
