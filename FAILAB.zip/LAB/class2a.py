class SimpleReflexAgent:
    def __init__(self):
        self.rules = {
            'clean': 'no-op',
            'dirt': 'clean'
        }

    def perceive(self, environment):
        self.perception = environment

    def act(self):
        action = self.rules.get(self.perception, 'no-op')
        return action

if __name__ == "__main__":
    agent = SimpleReflexAgent()
    environment_states = ['dirt', 'clean', 'dirt', 'clean']
    for state in environment_states:
        agent.perceive(state)
        action = agent.act()
        print(f"Perception: {state}, Action: {action}")
