from collections import deque

def ac3(csp):
    queue = deque(csp['arcs'])  
    while queue:
        (X, Y) = queue.popleft()  
        if revise(csp, X, Y):  
            if not csp['domains'][X]:  
                return False
            for Z in csp['neighbors'][X]:  
                if Z != Y:  
                    queue.append((Z, X))
    return True  

def revise(csp, X, Y):
    revised = False
    for x in csp['domains'][X][:]:  
        if not any(satisfies_constraint(x, y, X, Y, csp) for y in csp['domains'][Y]):
            csp['domains'][X].remove(x)  
            revised = True
    return revised

def satisfies_constraint(x, y, X, Y, csp):
    return True  

# Example usage
csp_example = {
    'domains': {
        'A': [1, 2, 3],
        'B': [2, 3],
        'C': [1, 3]
    },
    'arcs': [
        ('A', 'B'),
        ('B', 'A'),
        ('A', 'C'),
        ('C', 'A')
    ],
    'neighbors': {
        'A': ['B', 'C'],
        'B': ['A'],
        'C': ['A']
    }
}

if ac3(csp_example):
    print("Arc consistency achieved: ", csp_example['domains'])
else:
    print("No solution exists, a domain is empty.")
