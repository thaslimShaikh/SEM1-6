import heapq

def uniform_cost_search(graph, start, goal):
    frontier = []
    heapq.heappush(frontier, (0, start))

    came_from = {start: None}
    cost_so_far = {start: 0}

    while frontier:
        current_cost, current_node = heapq.heappop(frontier)
        if current_node == goal:
            break
        for neighbor, cost in graph[current_node].items():
            new_cost = cost_so_far[current_node] + cost
            if neighbor not in cost_so_far or new_cost < cost_so_far[neighbor]:
                cost_so_far[neighbor] = new_cost
                priority = new_cost
                heapq.heappush(frontier, (priority, neighbor))
                came_from[neighbor] = current_node

    path = []
    if goal in came_from:
        node = goal
        while node is not None:
            path.append(node)
            node = came_from[node]
        path.reverse()

    return path, cost_so_far.get(goal, float('inf'))

if __name__ == "__main__":
    graph = {
        'A': {'B': 1, 'C': 4},
        'B': {'A': 1, 'C': 2, 'D': 5},
        'C': {'A': 4, 'B': 2, 'D': 1},
        'D': {'B': 5, 'C': 1}
    }
    start_node = 'A'
    goal_node = 'D'

    path, cost = uniform_cost_search(graph, start_node, goal_node)
    print("Path:", path)
    print("Cost:", cost)


#heapq library for efficient priority queue management: smallest element will be at front.
#UCS: to find the least costly path between a starting node and a goal node in a weighted graph
#frontier: min-heap
