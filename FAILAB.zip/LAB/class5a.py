from collections import deque

def bidirectional_search(graph, start, goal):
    if start == goal:
        return [start]

    # Initialize the forward and backward search
    front_visited = {start: None}
    back_visited = {goal: None}
    front_queue = deque([start])
    back_queue = deque([goal])

    while front_queue and back_queue:
        # Forward search
        current_node = front_queue.popleft()
        for neighbor in graph[current_node]:
            if neighbor not in front_visited:
                front_visited[neighbor] = current_node
                front_queue.append(neighbor)
                if neighbor in back_visited:
                    return reconstruct_path(front_visited, back_visited, neighbor)

        # Backward search
        current_node = back_queue.popleft()
        for neighbor in graph[current_node]:
            if neighbor not in back_visited:
                back_visited[neighbor] = current_node
                back_queue.append(neighbor)
                if neighbor in front_visited:
                    return reconstruct_path(front_visited, back_visited, neighbor)

    return None

def reconstruct_path(front_visited, back_visited, meeting_node):
    path = []
    # Reconstruct path from start to meeting node
    step = meeting_node
    while step is not None:
        path.append(step)
        step = front_visited[step]
    path.reverse()

    #Reconstruct path from meeting node to goal
    step = back_visited[meeting_node]
    while step is not None:
        path.append(step)
        step = back_visited[step]
    return path

#Example graph(undirected)
graph = {
    'A': ['B', 'C'],
    'B': ['A', 'D', 'E'],
    'C': ['A', 'F'],
    'D': ['B'],
    'E': ['B', 'G'],
    'F': ['C'],
    'G': ['E']
}

#Example usage
start_node = 'A'
goal_node = 'G'
path = bidirectional_search(graph, start_node, goal_node)
print(f'Path from {start_node} to {goal_node}: {path}')
