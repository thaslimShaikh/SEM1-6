##you have to choose an action with maximum utility value??
class UtilityBasedReflexAgent:

    def __init__(self):
        # Define the utility function for different states
        self.utility = {
            'state1': 1,
            'state2': 0.5,
            'state3': 0,
            'state4': 0.2
        }
        # Define the actions for different states
        self.actions = {
            'state1': 'Action1',
            'state2': 'Action2',
            'state3': 'Action3',
            'state4': 'Action4'
        }

    def get_best_action(self):
        # Find the state with the maximum utility value
        best_state = max(self.utility, key=self.utility.get)
        # Get the action for the state with the maximum utility
        return self.actions.get(best_state, 'Unknown Action')

    def decide_action(self):
        best_action = self.get_best_action()
        return best_action

# Example usage
if __name__ == "__main__":
    agent = UtilityBasedReflexAgent()
    action = agent.decide_action()
    print(f"The agent chooses '{action}' with the maximum utility value.")
