def dfs(graph, start, visited=None):
    if visited is None:
        visited = set()
    visited.add(start)
    print(start)
    for neighbor in graph[start]:
        if neighbor not in visited:
            dfs(graph, neighbor, visited)
    return visited

if __name__ == "__main__":
    graph = {
        'A': ['B', 'C', 'D'],
        'B': ['C', 'F'],
        'C': ['A'],
        'D': ['A', 'C', 'E'],
        'E': ['F'],
        'F': ['D', 'E']     
    }
    print("DFS traversal starting from node 'A':")
    dfs(graph, 'A')

#it explores as far as possible along each branch before backtracking.
