from collections import deque
def bfs(graph, start):
  visited = set() 
  queue = deque([start])

  while queue:
    node = queue.popleft()
    if node not in visited:
      print(node)
      visited.add(node)
      queue.extend(neighbor for neighbor in graph[node] if neighbor not in visited)

graph = {
  'A': ['B', 'C'],
  'B': ['A', 'D', 'E'],
  'C': ['A', 'F'],
  'D': ['B'],
  'E': ['B', 'F'],
  'F': ['C', 'E']
}

bfs(graph, 'A')


#time complexity: O(V + E)
#deque: fast push, pop operations
#it visits nodes level by level, explaoring all neighbors of the current node before moving to the next level.



