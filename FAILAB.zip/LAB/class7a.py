class PropositionalLogic:
    def __init__(self):
        self.variables = {}                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
    def set_variable(self, var, value):
        self.variables[var] = value

    def evaluate(self, expr):
        expr = expr.replace("AND", "and").replace("OR", "or").replace("NOT", "not").replace("IMPLIES", "or not")

        for var in self.variables:
            expr = expr.replace(var, str(self.variables[var]))

        return eval(expr)

    def and_op(self, p, q):
        return p and q

    def or_op(self, p, q):
        return p or q

    def not_op(self, p):
        return not p

    def implies(self, p, q):
        return not p or q

# Example usage
if __name__ == "__main__":

    logic = PropositionalLogic()

    logic.set_variable("A", True)
    logic.set_variable("B", False)

    expression = "A AND NOT B"  # A ∧ ¬B
    result = logic.evaluate(expression)
    print(f"Result of '{expression}': {result}")
    
    # Test OR operation
    expression = "A OR B"  # A ∨ B
    result = logic.evaluate(expression)
    print(f"Result of '{expression}': {result}")
    
    # Test IMPLIES operation
    expression = "A IMPLIES B"  # A → B
    result = logic.evaluate(expression)
    print(f"Result of '{expression}': {result}")
    
    # More complex expressions
    expression = "NOT (A AND B)"  # ¬(A ∧ B)
    result = logic.evaluate(expression)
    print(f"Result of '{expression}': {result}")
