clc; clear all; close all; 
ts=0.001; 
[DOF2_manu,manuInfo]=importrobot('lab_2'); 