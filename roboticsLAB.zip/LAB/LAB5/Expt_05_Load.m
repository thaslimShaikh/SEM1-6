clc;
clear all;
close all;
ts = 0.001;
[DOF3_RRR, manuInfo] = importrobot('Expt_05');